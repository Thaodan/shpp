 #!/bin/sh -e

# build src to build 

#### Config ###

if [ ! -e src ] ; then 
  cd ../.. # cd to source dir
fi
PROJECT_NAME=sh-make-tools

TARGET_DIR=dist/source
DIST_DIR=dist
. $PWD/src/sh_makefile

BUILD_TMP=sh-make-tools-$VER
BUILD_FILE=$PROJECT_NAME-$VER.tar.gz # use projekt $VER when build src archive 
######################
### excute part ###

mkdir $BUILD_TMP
sh -c  'cd src; . $PWD/sh_makefile; clean'
sh -c "cd $DIST_DIR; . \$PWD/dist_clean"
# only list  directorys and files that are in root to copy them in to $BUILD_TMP and exclude backups (files with ~ at the end) #  -e 's/^.//' -e  's/^\///'
for file in $( find  ! -iname '*~' ! -name  '*.tar.*' ! -name 'dist/pacman/{src,pkg}' | sed -e '1 d' -e 's/^.\///') ; do 
  mkdir -p $BUILD_TMP/$( dirname $file ); 
  if [ ! -d $file ] ; then
    cp $file $BUILD_TMP/$file ;
  fi 
done 
# cd $BUILD_TMP
# clean uneeeded archives in our source dist
# rm -rf dist/pacman/*.tar.xz
# rm -rf dist/pacman/{pkg,src}
# rm -rf dist/source/*.tar.gz
# rm -rf dist/source/${PROJECT_NAME}_latest # remove link to latest archive too
# rm -rf ${PROJECT_NAME}_latest.tar.gz
# rm -rf build_src.sh
tar -caf $TARGET_DIR/$BUILD_FILE $BUILD_TMP
#mv $BUILD_FILE ../$TARGET_DIR/$BUILD_FILE
#cd .. # go back to source dir
rm -rf $BUILD_TMP

rm -rf $TARGET_DIR/${PROJECT_NAME}_latest

ln -s $BUILD_FILE $TARGET_DIR/${PROJECT_NAME}_latest.tar.gz # link to latest source
ln -s $PWD/$TARGET_DIR/${PROJECT_NAME}_latest.tar.gz ${PROJECT_NAME}_latest.tar.gz # same but now in $PROJECT_NAME root
